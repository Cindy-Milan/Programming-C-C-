#include "PlaylistNode.h"

PlaylistNode::PlaylistNode()
{//ctor
    nextNodePtr = 0;
    uniID = "none";
    soName = "none";
    artName = "none";
    soLength = 0;
}

PlaylistNode::PlaylistNode(string Idef, string sName, string aName, int sLength)
{
	uniID = Idef;
	soName = sName;
	artName = aName;
	soLength = sLength;
}

void PlaylistNode::InsertAfter(PlaylistNode *relocate){
   PlaylistNode *temp = 0;

   temp = nextNodePtr;
   nextNodePtr = relocate;
   relocate->nextNodePtr = temp;

}

void PlaylistNode::SetNext(PlaylistNode *relocate){
    nextNodePtr = relocate;
}

string PlaylistNode::GetID(){
    return uniID;
}

string PlaylistNode::GetSongName(){
    return soName;
}

string PlaylistNode::GetArtistName(){
    return artName;
}
int PlaylistNode::GetSongLength(){
    return soLength;
}
PlaylistNode* PlaylistNode::GetNext(){
    return nextNodePtr;
}

void PlaylistNode::PrintPlaylistNode(){
cout << "Unique ID: " << uniID << endl;
cout << "Song Name: " << soName << endl;
cout << "Artist Name: " << artName << endl;
cout << "Song Length (in seconds): " << soLength << endl<<endl;
}