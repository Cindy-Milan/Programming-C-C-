#ifndef PLAYLISTNODE_H
#define PLAYLISTNODE_H

#include <string>	// Need this for strings!
#include <iostream>	// Need this for input and output!
using namespace std;	// use this! it's so you don't need to write string::string, etc

class PlaylistNode
{
    public:
        PlaylistNode();
        PlaylistNode(string Idef, string sName, string aName, int sLength );
        void InsertAfter(PlaylistNode* relocate);
        void SetNext(PlaylistNode* locate);
        string GetID();
        string GetSongName();
        string GetArtistName();
        int GetSongLength();
        PlaylistNode* GetNext();
        void PrintPlaylistNode();

    /*
    These are the functions needed to use for the linked list, it is formated in the Playlist.cpp file and used in the main.cpp file
    */
    protected:
    private:
        PlaylistNode* nextNodePtr;
        string uniID;
        string soName;
        string artName;
        int soLength;

        /*
        variables that are not allowed to edit from outside functions
        */
};

#endif // PLAYLISTNODE_H