/*
Cynthia Milan
Prof. Richard Biritwum
Antelope Valley College
Computer Engineering Undergrad Student
*/

#include "PlaylistNode.h"	// Needed to include PlaylistNode.h in order to use all the class stuff!
// Any of the #include from the header file doesn't need to be here since it is included in PlaylistNode.h!

using namespace std;
void PrintMenu(string playList){

cout << playList << " PLAYLIST MENU"<<endl;   //Prints the menu in the menu options
cout <<"a - Add song" << endl;
cout <<"d - Remove song"<<endl;
cout <<"c - Change position of song"<<endl;
cout <<"s - Output songs by specific artist"<<endl;
cout <<"t - Output total time of playlist (in seconds)"<<endl;
cout <<"o - Output full playlist"<<endl;
cout <<"q - Quit"<<endl<<endl;
cout <<"Choose an option:";

}
int main()
{
    PlaylistNode *currentNode = 0;
    PlaylistNode *headNode = 0;
    PlaylistNode *lastNode = 0;


string lost; //misspelled on purpose aka "list"
cout << "Enter playlist's title:" << endl;
cout << endl;
getline(cin, lost);
/////////////////////////////////
//PrintMenu(lost);
/////////////////////////////////
char lostOp; //misspelled on purpose
bool music = true;                          //Allows the user to quit the program
while(music){

    PrintMenu(lost);
	cin >> lostOp;                          //Asks the user for the option
	cout << endl;

    if(lostOp == 'a'){
            string w,x,y;
            int z;

            cin.ignore();               // without this, the print menu was in an infinite loop

            cout <<"ADD SONG"<<endl;
            cout <<"Enter song's unique ID:"<<endl;
            getline(cin, w);
            cout <<"Enter song's name:"<<endl;
            getline(cin,x);
            cout << "Enter artist's name:"<<endl;
            getline(cin,y);
            cout << "Enter song's length (in seconds):"<<endl;
			cin >> z;
			cout << endl;

        currentNode = new PlaylistNode(w,x,y,z);   // creates the new node to be added
        if(headNode==0){                           // reads to see if there is any node in the list
            headNode = currentNode;
            lastNode = currentNode;
        }
        else if(headNode != 0){                    // if there is, then it inserts it at the end
            lastNode->InsertAfter(currentNode);
            lastNode = currentNode;
        }


    }
    else if(lostOp == 'd'){
        string a;
        cout << "REMOVE SONG"<<endl;
        cin.ignore();
        cout << "Enter song's unique ID:" << endl;
        getline(cin, a);

        PlaylistNode *temp1 = 0;
        PlaylistNode *temp2 = 0;
        temp1 = headNode;

        while(temp1 != 0){
           if(temp1->GetNext()->GetID() == a){ // searches for the node before the one you want to delete
            break;
           }
           temp1 = temp1->GetNext();           // runs through the linked list
        }
        temp2 = temp1->GetNext();              // grabs the one you want to delete
        cout <<"\""<<temp2->GetSongName()<<"\" removed."<<endl<<endl;   // Prints the node
        temp2=temp2->GetNext();
        temp1->SetNext(temp2);                 // removes the node so the previous node links to the node after the deleted one




    }

    else if(lostOp == 'c'){

    // Still under development

    }

    else if(lostOp == 's'){
        string i;
        int q = 1;

        cin.ignore();                                               //stops the reprints of the menu
        cout <<lost<< " - OUTPUT SONGS BY SPECIFIC ARTIST"<<endl;
        cout << "Enter artist's name:"<<endl;
        getline(cin,i);
        cout << endl;


        currentNode = headNode;
        while(currentNode != 0){
            if(currentNode->GetArtistName() == i){              //scans for the given artist
            cout << q << "."<<endl;                             // numbers each song
            currentNode->PrintPlaylistNode();                   // prints the song information
            //cout << endl;
                }
                currentNode = currentNode->GetNext();           //
                q++;
        }




    }

    else if(lostOp == 't'){

        int q = 0;
        cout<<lost<<" - OUTPUT TOTAL TIME OF PLAYLIST (IN SECONDS)"<<endl;

        currentNode = headNode;
        while(currentNode != 0){
            q+= currentNode->GetSongLength();
            currentNode = currentNode->GetNext();
        }
        cout << "Total time: " << q << " seconds" <<endl<<endl;
    }

    else if(lostOp == 'o'){

        int q = 1;

        cout << lost << " - OUTPUT FULL PLAYLIST" <<endl;

        if(headNode == 0){
            cout << "Playlist is empty"<<endl<<endl;
        }
        else{
        currentNode = headNode;
        while(currentNode != 0){
            cout << q << "."<<endl;
            q++;
            currentNode->PrintPlaylistNode();
            currentNode = currentNode->GetNext();
        }

        }

    }

    else if(lostOp == 'q'){
        music = false;
    }

    else{
        cout << "Please pick a valid option"<<endl<<endl;
        cout << "Choose an option:" << endl;

    }
}

    return 0;
}