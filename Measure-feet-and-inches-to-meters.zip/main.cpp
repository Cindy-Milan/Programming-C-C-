/*
Cynthia Milan
Honors Option Assignment
Prof. Biritwum
4-26-2018
CIS 173
*/

#include <iostream>
#include <iomanip>
#include<cstdio>

using namespace std;

void input(int& feet, double& inches){ // shows the input properly on the screen

 cout << feet <<" feet and "<<inches<<" inches." << endl;
}

double convert(int feet, double inches, double& meters){ // converts the given units into meters
   double INCHES_PER_FOOT = 12;              // there are 12 inches per foot
   double METERS_PER_FOOT = 0.3048;         // there are 0.3048 meters per foot

   meters = ((METERS_PER_FOOT)*((feet)+(inches/INCHES_PER_FOOT)));  // calculates the units into meters

    return meters;                  // returns the calculation
}

void output(int feet, double inches, double meters){                        // prints the everything that was inputed and calculated
    cout << "The value of feet, inches: " << feet <<" ft., "<<inches<< " in." <<endl<<endl;   // prints the given input
    cout << "Converted to meters, centimeters: " << setprecision(2) << fixed << meters <<endl;  // prints the calculated output in meters set to 2 decimal points
}

int main()
{
    int ft;                         // given variables to use
    double in;
    double m;


    cout << "Please input feet and inches" <<endl<<endl;

    cout << "Feet: "<<endl;            // asks the user to input a number of feet
    cin >> ft;                    //asks for input
    cout<<endl;

    cout<<"Inches: "<<endl;             // asks the user to input a number of inches
    cin >> in;                    //asks for input
    cout<<endl;

    input(ft, in);              // recalls the function to show the given inputs
    cout<<endl;

    convert(ft, in, m);        //calculates the inputs
    cout<<endl;

    output(ft, in, m);          // shows the final calculation along with the given units
    cout<<endl;

    return 0;
}